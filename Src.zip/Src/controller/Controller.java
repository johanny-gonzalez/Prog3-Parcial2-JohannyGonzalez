package app.controller;

import app.model.*;
import app.util.ArchivoManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.time.LocalDateTime;
import java.util.ArrayList;


public class Controller<Entidad, Historial> {

    @FXML
    private TextField txtNombreMascota;

    @FXML
    private TextField txtCategoria;

    @FXML
    private TextField txtCantidad;

    @FXML
    private TextField txVeterinario;

    @FXML
    private ComboBox<String> comboEstado;

    /**
 *
 */
   @FXML
    private TableView<> tabla;

    @FXML
    private TableColumn<Entidad,String> colCodigo;

    @FXML
    private TableColumn<Entidad,String> colNombre;

    @FXML
    private TableColumn<Entidad,String> colCategoria;

    @FXML
    private TableColumn<Entidad,Integer> colCantidad;

    @FXML
    private TableColumn<Entidad,String> colEstado;

    @FXML
    private TableView<Historial> tablaHistorial;

    private ObservableList<Entidad> lista =
            FXCollections.observableArrayList();

    private ObservableList<Historial> historial =
            FXCollections.observableArrayList();

    @FXML
    public void initialize(Object ArchivoManager){

        ArrayList<Entidad> datos =
                ((Object) ArchivoManager).cargarDatos();

        lista.addAll(datos);

        ComboBox<String> tabla;
        tabla.setItems(lista);

        comboEstado.setItems(
                FXCollections.observableArrayList(
                        "Activo",
                        "Inactivo"
                )
        );

        ((TableView<Historial>) tabla).refresh();

    }

    @FXML
    public void registrar(){

        try{

            if(txtNombre.getText().isEmpty()){

                alerta("Debe escribir un nombre");

                return;

            }

            Entidad e =
                    new Entidad(
                            generarCodigo(),
                            txtNombre.getText(),
                            txtCategoria.getText(),
                            Integer.parseInt(
                            txtCantidad.getText()
                            ),
                            comboEstado.getValue()
                    );

            lista.add(e);

            ArchivoManager.guardarDatos(
                    new ArrayList<>(lista)
            );

            limpiar();

        }catch(Exception ex){

            alerta("Datos incorrectos");


        }

    }

    private String generarCodigo(){

        return "COD"
                +(lista.size()+1);
    }

    @FXML
    public void eliminar(){

        Entidad seleccionado =
                tabla.getSelectionModel()
                .getSelectedItem();

        if(seleccionado==null){

            alerta("Seleccione un elemento");

            return;

        }

        seleccionado.setEstado(
                "Inactivo"
        );

        agregarHistorial(
                seleccionado,
                "Cambio de estado"
        );

        tabla.refresh();
    }

    @FXML
    public void realizarOperacion(){

        try{

            Entidad seleccionado =
                    tabla.getSelectionModel()
                    .getSelectedItem();

            if(seleccionado==null){

                throw new ExcepcionOperacion(
                        "Seleccione un elemento"
                );
                
            }

            if(seleccionado.getEstado()
                    .equals("Inactivo")){


                throw new ExcepcionEstado(
                        "Elemento bloqueado"
                );

            }

            seleccionado.setCantidad(
                    seleccionado.getCantidad()-1
            );

            agregarHistorial(
                    seleccionado,
                    "Operacion realizada"
            );

            ArchivoManager.guardarDatos(
                    new ArrayList<>(lista)
            );

        }
        catch(Exception e){

            alerta(e.getMessage());

        }

    }

    private void agregarHistorial(
            Entidad e,
            String operacion){

        Historial h =
                new Historial(
                        LocalDateTime.now()
                        .toString(),
                        ((Object) e).getCodigo(),
                        operacion,
                        txVeterinario.getText(),
                        "Proceso realizado"
                );

        historial.add(h);

    }

    @FXML
    public void limpiar(){


        TextInputControl txtNombre;
        txtNombre.clear();

        txtCategoria.clear();

        txtCantidad.clear();

        txVeterinario.clear();

    }

    private void alerta(String mensaje){

        Alert a =
                new Alert(
                Alert.AlertType.ERROR
                );


        a.setContentText(mensaje);

        a.show();

    }

}