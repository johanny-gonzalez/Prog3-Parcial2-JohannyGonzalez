package app.model;


public class ExcepcionEstado extends Exception{


    public ExcepcionEstado(String mensaje){

        super(mensaje);

    }

}