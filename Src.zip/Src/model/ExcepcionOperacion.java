package app.model;


public class ExcepcionOperacion extends Exception{


    public ExcepcionOperacion(String mensaje){

        super(mensaje);

    }

}