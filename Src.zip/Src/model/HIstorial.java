package app.model;


public class Historial {

    private String fecha;
    private String codigoMacosta;
    private String operacion;
    private String Veterinario;
    private String descripcion;

    public Historial(String fecha,
                     String codigoMascota,
                     String operacion,
                     String Veterinario,
                     String descripcion){

        this.fecha = fecha;
        this.codigo = codigoMascota;
        this.operacion = operacion;
        this.Veterinario = Veterinario;
        this.descripcion = descripcion;

    }

    public String getFecha(){

        return fecha;

    }

    public String getCodigoMascota(){

        return codigoMascota;

    }

    public String getOperacion(){

        return operacion;

    }

    public String getVeterinario(){

        return Veterinario;

    }

    public String getDescripcion(){

        return descripcion;

    }


}