package app.model;


public class Entidad {

    private String getCodigoMascota;
    private String nombre;
    private String Edad;
    private String Dueno;
    private String Especie;
    private int cantidad;
    private String estado;


    public Entidad(String getCodigoMascota,
                   String nombre,
                   String categoria,
                   String Edad,
                   String Dueno,
                   String Especie,
                   int cantidad,
                   String estado){

        this.codigo = Edad;
        this.nombre = nombre;
        this.categoria = categoria;
        this.cantidad = cantidad;
        this.estado = estado;

    }

    public String getCodigoMacosta(){

        return getDueno;

    }

    public String getEdad(){

        return codigo;

    }

    public String getNombre(){

        return nombre;

    }

    public String getCategoria(){

        return categoria;

    }

    public int getCantidad(){

        return cantidad;

    }

    public String getEstado(){

        return estado;

    }

    public void setCantidad(int cantidad){

        this.cantidad = cantidad;

    }

    public void setEstado(String estado){

        this.estado = estado;

    }

    @Override
    public String toString(){

        return codigo+"-"+nombre;

    }


}