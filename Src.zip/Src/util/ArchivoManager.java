package app.util;


import app.model.Entidad;
import app.model.Historial;

import java.io.*;
import java.util.ArrayList;



public class ArchivoManager {

    private static final String ARCHIVO_DATOS = "datos.txt";
    private static final String ARCHIVO_HISTORIAL = "historial.txt";


    public static void guardarDatos(ArrayList<Entidad> lista){

        try{

            PrintWriter pw =
                    new PrintWriter(
                    new FileWriter(ARCHIVO_DATOS)
                    );

            for(Entidad e : lista){


                pw.println(
                        e.getCodigo()+";"
                        +e.getNombre()+";"
                        +e.getCategoria()+";"
                        +e.getCantidad()+";"
                        +e.getEstado()
                );


            }

            pw.close();


        }catch(IOException e){

            System.out.println("Error guardando datos");

        }


    }

    public static ArrayList<Entidad> cargarDatos(){


        ArrayList<Entidad> lista =
                new ArrayList<>();

        try{

            File archivo =
                    new File(ARCHIVO_DATOS);

            if(!archivo.exists()){

                return lista;

            }

            BufferedReader br =
                    new BufferedReader(
                    new FileReader(archivo)
                    );

            String linea;

            while((linea=br.readLine())!=null){

                String datos[] =
                        linea.split(";");

                Entidad e =
                        new Entidad(
                        datos[0],
                        datos[1],
                        datos[2],
                        Integer.parseInt(datos[3]),
                        datos[4]
                );

                lista.add(e);

            }

            br.close();

        }catch(Exception e){

            System.out.println("Error cargando datos");

        }

        return lista;

    }

    public static void guardarHistorial(ArrayList<Historial> lista){

        try{

            PrintWriter pw =
                    new PrintWriter(
                    new FileWriter(ARCHIVO_HISTORIAL)
                    );

            for(Historial h : lista){

                pw.println(

                        h.getFecha()+";"
                        +h.getCodigoMascota()+";"
                        +h.getOperacion()+";"
                        +h.getVeterinario()+";"
                        +h.getDescripcion()
                );

            }

            pw.close();

        }catch(IOException e){

            System.out.println("Error historial");

        }

    }

}